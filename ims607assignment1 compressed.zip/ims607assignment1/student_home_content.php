<h2>Welcome, Student!</h2>
<p>Here you can view available internships, apply for them, and manage your applications.</p>