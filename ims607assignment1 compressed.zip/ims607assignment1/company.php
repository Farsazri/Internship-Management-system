<?php
require 'config.php';

// Functions to handle company-related operations
?>