<h2>Welcome, Supervisor!</h2>
<p>You can view students under your supervision and their internship details here.</p>