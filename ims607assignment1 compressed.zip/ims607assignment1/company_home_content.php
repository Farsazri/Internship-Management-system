<h2>Welcome, Company!</h2>
<p>Manage your internship postings and review student applications here.</p>