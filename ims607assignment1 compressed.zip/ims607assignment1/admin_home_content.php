<h2>Welcome, Admin!</h2>
<p>You have the control to manage all users and their roles within the system.</p>